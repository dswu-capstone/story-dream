package com.storydream.backend.domain.focus.entity;

public enum FocusStatus {
    FRONT,    // 정면 = 집중
    SIDE,     // 옆모습
    BACK,     // 뒷모습
    ABSENT;   // 자리 이탈 (미검출)

    public boolean isDistracted() {
        return this != FRONT;
    }
}
