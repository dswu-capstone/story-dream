package com.storydream.backend.domain.focus.dto;

import com.storydream.backend.global.common.PartType;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;

public record FocusEventRequest(
        @NotBlank String eventType,   // focus_lost / absent / focus_recovered / focus_state
        @NotBlank String state,       // front / side / back / absent
        String detail,
        @NotNull PartType partType,
        @NotNull @Min(1) @Max(3) Integer level,
        LocalDateTime occurredAt
) {}
