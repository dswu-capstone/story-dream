package com.storydream.backend.domain.report.entity;

public enum ReportStatus {
    PENDING,      // 생성 대기
    PROCESSING,   // 집계 완료, AI 요약 생성 중
    COMPLETED,
    FAILED        // AI 호출 실패 → 재시도 대상
}
