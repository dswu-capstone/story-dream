package com.storydream.backend.domain.report.dto;

import com.storydream.backend.domain.report.entity.AiReportPartDetail;

public record PartTrendResponse(
        String partType,          // "서론" / "본론" / "결론"  → 두 그래프의 X축
        int orderNum,
        int level,                // 난이도 변화 그래프 Y축 (1~3)
        double accuracy,          // 평균 정답률 그래프 Y축 (0~100)
        int quizTotal,
        int quizCorrect,
        int distractionCount,
        int distractionSec
) {
    public static PartTrendResponse from(AiReportPartDetail p) {
        return new PartTrendResponse(
                p.getPartType().getDbValue(),
                p.getOrderNum(),
                p.getLevel(),
                p.getAccuracy().doubleValue(),
                p.getQuizTotal(),
                p.getQuizCorrect(),
                p.getDistractionCount(),
                p.getDistractionSec()
        );
    }
}
