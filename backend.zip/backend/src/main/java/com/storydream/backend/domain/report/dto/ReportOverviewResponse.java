package com.storydream.backend.domain.report.dto;

import java.time.LocalDate;
import java.util.List;

public record ReportOverviewResponse(
        Integer childId,
        String childName,
        LocalDate periodStart,
        LocalDate periodEnd,
        int totalReadingCount,
        Double averageQuizScore,      // 독서 0건이면 null
        Double averageFocusRate,
        List<WeeklyScorePoint> weeklyScores,
        String aiSummary,
        String summaryStatus
) {
    public record WeeklyScorePoint(
            String label,             // "5/1 ~ 5/7"
            LocalDate weekStart,
            LocalDate weekEnd,
            int readingCount,
            Double averageQuizScore   // 독서 없는 주는 null
    ) {}
}
