package com.storydream.backend.domain.report.repository.projection;

import java.math.BigDecimal;

public interface PeriodAggregate {
    Long getReportCount();
    BigDecimal getAvgScore();       // 리포트 0건이면 null
    BigDecimal getAvgFocusRate();   // 리포트 0건이면 null
}
